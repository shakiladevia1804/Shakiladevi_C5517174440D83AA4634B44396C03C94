n = int(input("Enter the year"))
if (n % 4 == 0):
  print("Leap Year")
else:
  print("Not a Leap Year")
